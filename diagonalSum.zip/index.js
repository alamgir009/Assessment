let arr = [
  [1, 2, 3, 4],
  [5, 6, 7, 8],
  [9, 10, 11, 12],
  [13, 14, 15, 16],
];

let sum = 0;
let b;
// for (let i = 0; i < arr.length; i++) {
//   let a = arr[0];
//   for (let j = 0; j < a.length; j++) {
//     b = arr[i][j];
//   }
//   console.log(b);
// }

for (let i = 0; i < arr.length; i++) {
  sum += arr[i][i];
  console.log(arr[i][i]);
}

// console.log(sum);
